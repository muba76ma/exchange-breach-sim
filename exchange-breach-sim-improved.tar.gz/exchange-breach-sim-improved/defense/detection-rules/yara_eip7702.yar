rule EIP7702_Sweeper_Bytecode
{
    meta:
        description = "Heuristic match for educational EIP-7702 sweeper contract patterns"
        author      = "exchange-breach-sim"
        date        = "2026-10-30"
        reference   = "LAB-NOTES.md – concept only"
    strings:
        $sweeper = "Sweeper" ascii nocase
        $recv    = "receive()" ascii
        $fallback = "fallback()" ascii
        $dead    = "0x000000000000000000000000000000000000dEaD" ascii
    condition:
        uint16(0) == 0x6080 and 2 of them
}
