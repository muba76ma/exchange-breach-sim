#!/usr/bin/env python3
"""Hardened withdrawal guard – dual control + velocity + timelock."""
from flask import Flask, request, jsonify
import os
import time
import logging
import json
from collections import defaultdict

app = Flask(__name__)

LOG_FORMAT = os.getenv("LOG_FORMAT", "text")
SECOND_APPROVER = os.getenv("SECOND_APPROVER", "compliance-service")
WINDOW = int(os.getenv("VELOCITY_WINDOW_SECONDS", "60"))
MAX_PER_WINDOW = int(os.getenv("VELOCITY_MAX_REQUESTS", "3"))
LARGE_THRESHOLD = float(os.getenv("LARGE_AMOUNT_THRESHOLD", "1.0"))
TIMELOCK = int(os.getenv("TIMELOCK_SECONDS", "5"))

_recent = defaultdict(list)

if LOG_FORMAT == "json":
    class JsonFormatter(logging.Formatter):
        def format(self, record):
            log_obj = {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
                "level": record.levelname,
                "msg": record.getMessage(),
                "service": "layered-withdrawal-guard",
            }
            return json.dumps(log_obj)
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    logging.root.handlers = [handler]
    logging.root.setLevel(logging.INFO)
else:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")


@app.route("/internal/withdraw", methods=["POST"])
def withdraw():
    svc = request.headers.get("X-Service-Identity", "")
    approver = request.headers.get("X-Second-Approval", "")
    body = request.get_json(silent=True) or {}
    try:
        amount = float(body.get("amount", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "invalid amount"}), 400

    now = time.time()

    # Velocity check
    _recent[svc] = [t for t in _recent[svc] if now - t < WINDOW]
    if len(_recent[svc]) >= MAX_PER_WINDOW:
        logging.warning(f"velocity limit hit svc={svc} count={len(_recent[svc])}")
        return jsonify({"error": "velocity limit", "window_seconds": WINDOW}), 429
    _recent[svc].append(now)

    # Dual control for large amounts
    if amount >= LARGE_THRESHOLD and approver != SECOND_APPROVER:
        logging.warning(
            f"missing second approval svc={svc} amount={amount} asset={body.get('asset')}"
        )
        return jsonify({"error": "second approval required"}), 403

    logging.info(
        f"queued with timelock={TIMELOCK}s svc={svc} amount={amount} asset={body.get('asset')}"
    )
    # Educational short sleep (real systems would use an async queue)
    time.sleep(min(TIMELOCK, 1.5))
    return jsonify({
        "queued": True,
        "amount": amount,
        "asset": body.get("asset"),
        "timelock_seconds": TIMELOCK,
        "approver": approver or None,
    })


@app.route("/healthz")
def healthz():
    return "ok", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8091)
