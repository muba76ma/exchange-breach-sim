# LAB-NOTES — End-to-end walkthrough & real-incident mapping

## Vulnerable path (default stack)

```bash
bash attacker/01_simulate_laptop_compromise.sh
python3 attacker/02_forge_withdrawal_burst.py
```

Expected output (abbreviated):

```
[*] Phase 1: Laptop compromise simulation complete
[*] Phase 2: Forging multi-asset burst (simulating ~20 min window)...
[+] BTC  1.25   → signed
[+] ETH  45.0   → signed
[+] USDT 850000 → signed
[+] USDC 420000 → signed
...
[!] HSM auto-signed the entire burst because it trusted X-Service-Identity
```

**Why it works (the failure mode)**  
The HSM mock only checks the `X-Service-Identity` header. It does **not**:
- Verify a real client certificate / mTLS identity
- Check user-level authorization or session validity
- Enforce dual control / second approval
- Apply velocity or amount caps
- Require a short-lived signed request token

This is the core internal trust-chain failure the lab is designed to illustrate.

## Hardened path

```bash
python3 attacker/03_attack_hardened.py
```

Expected behaviour:
- First large request without second approval → **403 second approval required**
- With correct second-approval header → **queued with timelock**
- Rapid successive requests → **429 velocity limit**

## Issuer freeze simulation

```bash
python3 attacker/04_trigger_freeze.py
```

Mocks the public outcome where stablecoin issuers were able to freeze a large
fraction of the stolen USDT/USDC while BTC/ETH remained movable.

## Timeline comparison (public reporting vs lab)

| Real incident (approx)              | Lab equivalent                              |
|-------------------------------------|---------------------------------------------|
| T- hours/days: laptop compromise    | `01_simulate_laptop_compromise.sh`          |
| T+0 → T+20m: core multi-chain drain | `02_forge_withdrawal_burst.py`              |
| T+ minutes–hours: issuer freezes    | `04_trigger_freeze.py` + issuer-freeze svc  |
| T+ hours–days: attribution work     | Not modeled (out of scope)                  |
| Mixing / bridges / CEX hops         | Not modeled (separate lab recommended)      |

## Detection coverage

| Layer          | Rule / control                          | What it catches                                      |
|----------------|-----------------------------------------|------------------------------------------------------|
| Sigma          | `sigma_forged_withdrawal.yml`           | Trusted service identity without gateway auth        |
| Sigma          | `sigma_velocity_burst.yml`              | High-volume internal withdrawals in short window     |
| Sigma          | `sigma_missing_second_approval.yml`     | Large amount without dual control                    |
| YARA           | `yara_eip7702.yar`                      | Educational sweeper bytecode pattern                 |
| Runtime guard  | velocity + 2nd approval + timelock      | The entire forged-request class                      |

## What this lab intentionally does **not** model

- Real private-key extraction or HSM key export
- On-chain mixers, Tornado-style privacy tools, or cross-chain bridges
- Attribution tradecraft
- Production-grade mTLS / SPIFFE / service-mesh identity
- Full Proof-of-Reserves accounting after a drain

Those topics require separate, carefully scoped labs.

## Suggested blue-team exercises

1. Run the vulnerable path and collect the JSON logs. Write or improve a Sigma rule.
2. Switch the docker-compose to the hardened guard and re-run the attack. Observe the blocks.
3. Add a new amount-based policy and verify it fires.
4. Ship the structured logs to a local SIEM or OpenTelemetry collector and build a dashboard.
5. Discuss which additional controls (short-lived tokens, hardware-backed identity, offline dual control, etc.) would have raised the cost of the real attack.
