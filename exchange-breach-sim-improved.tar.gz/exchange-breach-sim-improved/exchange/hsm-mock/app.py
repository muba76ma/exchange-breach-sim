#!/usr/bin/env python3
"""HSM mock – deliberately weak identity check to illustrate the failure mode."""
from flask import Flask, request, jsonify
import os
import logging
import hashlib
import json
import time

app = Flask(__name__)

LOG_FORMAT = os.getenv("LOG_FORMAT", "text")
ALLOWED = os.getenv("ALLOWED_SERVICE_IDENTITY", "withdrawal-service")

if LOG_FORMAT == "json":
    class JsonFormatter(logging.Formatter):
        def format(self, record):
            log_obj = {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
                "level": record.levelname,
                "msg": record.getMessage(),
                "service": "hsm-mock",
            }
            return json.dumps(log_obj)
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    logging.root.handlers = [handler]
    logging.root.setLevel(logging.INFO)
else:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")


@app.route("/sign", methods=["POST"])
def sign():
    """Auto-sign if the caller claims the allowed service identity.
    Intentionally does NOT:
      - verify a real client certificate
      - check request signatures / short-lived tokens
      - enforce amount caps or dual control
      - rate-limit
    This is the educational failure mode.
    """
    svc = request.headers.get("X-Service-Identity", "")
    if svc != ALLOWED:
        logging.warning(f"rejected unauthorized service identity: {svc}")
        return jsonify({"error": "unauthorized service"}), 403

    body = request.get_json(silent=True) or {}
    # Fake deterministic signature (never a real key)
    material = f"{body.get('amount')}|{body.get('asset')}|{body.get('to')}|{body.get('user_id')}"
    fake_sig = hashlib.sha256(material.encode()).hexdigest()[:32]

    logging.info(
        f"HSM SIGNED amount={body.get('amount')} asset={body.get('asset')} "
        f"to={body.get('to')} sig={fake_sig}"
    )
    return jsonify({
        "signed": True,
        "signature": fake_sig,
        "amount": body.get("amount"),
        "asset": body.get("asset"),
        "to": body.get("to"),
    })


@app.route("/healthz")
def healthz():
    return "ok", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8082)
