#!/usr/bin/env python3
"""Mock stablecoin issuer freeze service.
Simulates the public outcome where issuers were able to freeze a large
fraction of stolen USDT/USDC while non-stable assets remained movable.
"""
from flask import Flask, request, jsonify
import os
import logging
import json
import time

app = Flask(__name__)

LOG_FORMAT = os.getenv("LOG_FORMAT", "text")
# In this educational mock we can "freeze" a percentage of stablecoin balances
FREEZABLE_ASSETS = {"USDT", "USDC"}

_frozen = {}  # address -> {asset: amount}

if LOG_FORMAT == "json":
    class JsonFormatter(logging.Formatter):
        def format(self, record):
            log_obj = {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
                "level": record.levelname,
                "msg": record.getMessage(),
                "service": "issuer-freeze",
            }
            return json.dumps(log_obj)
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    logging.root.handlers = [handler]
    logging.root.setLevel(logging.INFO)
else:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")


@app.route("/freeze", methods=["POST"])
def freeze():
    body = request.get_json(silent=True) or {}
    address = body.get("address", "unknown")
    asset = body.get("asset", "").upper()
    amount = body.get("amount", 0)

    if asset not in FREEZABLE_ASSETS:
        logging.info(f"cannot freeze non-stable asset={asset} address={address}")
        return jsonify({
            "frozen": False,
            "reason": "asset not freezable by issuer",
            "asset": asset,
        }), 200

    key = f"{address}:{asset}"
    _frozen[key] = float(amount)
    logging.info(f"FROZE {amount} {asset} at {address}")
    return jsonify({
        "frozen": True,
        "address": address,
        "asset": asset,
        "amount": amount,
    })


@app.route("/status", methods=["GET"])
def status():
    return jsonify({"frozen_entries": _frozen})


@app.route("/healthz")
def healthz():
    return "ok", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8092)
