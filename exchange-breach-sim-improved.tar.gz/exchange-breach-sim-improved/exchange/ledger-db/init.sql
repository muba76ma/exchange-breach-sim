-- Simple educational ledger. No real balances.
CREATE TABLE IF NOT EXISTS balances (
  id SERIAL PRIMARY KEY,
  user_id TEXT NOT NULL,
  asset TEXT NOT NULL,
  amount NUMERIC(28, 8) NOT NULL DEFAULT 0,
  UNIQUE (user_id, asset)
);

INSERT INTO balances (user_id, asset, amount) VALUES
  ('hotwallet-1', 'BTC',  12.50000000),
  ('hotwallet-2', 'ETH',  850.00000000),
  ('hotwallet-3', 'USDT', 2500000.00000000),
  ('hotwallet-4', 'USDC', 1800000.00000000),
  ('alice',       'BTC',  1.00000000),
  ('alice',       'ETH',  10.00000000),
  ('bob',         'USDT', 50000.00000000)
ON CONFLICT DO NOTHING;
