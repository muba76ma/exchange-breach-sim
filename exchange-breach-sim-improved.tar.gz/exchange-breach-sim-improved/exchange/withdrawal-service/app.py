#!/usr/bin/env python3
"""Vulnerable withdrawal service – demonstrates implicit trust failure."""
from flask import Flask, request, jsonify
import os
import requests
import logging
import json
import time

app = Flask(__name__)

LOG_FORMAT = os.getenv("LOG_FORMAT", "text")
HSM_URL = os.getenv("HSM_URL", "http://hsm-mock:8082")

if LOG_FORMAT == "json":
    class JsonFormatter(logging.Formatter):
        def format(self, record):
            log_obj = {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
                "level": record.levelname,
                "msg": record.getMessage(),
                "service": "withdrawal-service",
            }
            if hasattr(record, "extra"):
                log_obj.update(record.extra)
            return json.dumps(log_obj)
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    logging.root.handlers = [handler]
    logging.root.setLevel(logging.INFO)
else:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")


@app.route("/internal/withdraw", methods=["POST"])
def internal_withdraw():
    """Accepts internal withdrawal requests.
    Intentionally trusts only the X-Service-Identity header.
    This is the broken pattern under study.
    """
    svc = request.headers.get("X-Service-Identity", "unknown")
    body = request.get_json(silent=True) or {}
    logging.info(
        f"withdraw request received",
        extra={"svc": svc, "amount": body.get("amount"), "asset": body.get("asset"),
               "to": body.get("to"), "user_id": body.get("user_id")}
    )

    try:
        r = requests.post(
            f"{HSM_URL}/sign",
            json=body,
            headers={"X-Service-Identity": svc},
            timeout=5,
        )
        return jsonify(r.json()), r.status_code
    except Exception as e:
        logging.error(f"HSM call failed: {e}")
        return jsonify({"error": "hsm_unavailable"}), 502


@app.route("/healthz")
def healthz():
    return "ok", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8081)
