#!/usr/bin/env bash
# Phase 1 – Educational simulation of a compromised DevOps laptop.
# Copies only harmless mock files. No real credentials are involved.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="${ROOT}/lab/mock-laptop"
DST="${ROOT}/lab/attacker-loot"

mkdir -p "$DST"

echo "[*] T- hours: simulating infected laptop pulling cached session material"
echo "    (all files are mock placeholders – see ETHICS.md)"

for f in kubeconfig sts-token ssh-agent.sock service-cert.pem; do
  if [[ -f "${SRC}/${f}" ]]; then
    cp "${SRC}/${f}" "${DST}/${f}"
    echo "    [+] exfiltrated mock ${f}"
  else
    echo "    [-] mock ${f} missing (run make_lab or check lab/mock-laptop)"
  fi
done

echo "[*] Loot stored at ${DST}"
echo "[*] Next: python3 attacker/02_forge_withdrawal_burst.py"
