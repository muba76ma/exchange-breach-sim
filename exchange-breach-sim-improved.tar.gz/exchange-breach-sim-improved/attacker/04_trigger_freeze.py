#!/usr/bin/env python3
"""
Phase 4 – Educational simulation of stablecoin issuer freezes.
Shows why a portion of the stolen assets could be frozen while others could not.
"""
import json
import urllib.request
import urllib.error

FREEZE_URL = "http://127.0.0.1:8092/freeze"

# Mock stolen destinations (educational only)
CANDIDATES = [
    {"address": "TAttackerDemoUsdt001", "asset": "USDT", "amount": "850000"},
    {"address": "0xattackerDemoUsdc001", "asset": "USDC", "amount": "420000"},
    {"address": "bc1qattacker-demo-btc-001", "asset": "BTC",  "amount": "1.25"},
    {"address": "0xattackerDemoEth001", "asset": "ETH",  "amount": "45.0"},
]


def post(body: dict) -> tuple[int, str]:
    data = json.dumps(body).encode()
    req = urllib.request.Request(
        FREEZE_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def main():
    print("[*] Simulating issuer freeze coordination (educational)")
    print("    Stablecoins can be frozen by the issuer; BTC/ETH cannot.")
    print()

    for c in CANDIDATES:
        status, resp = post(c)
        data = json.loads(resp) if resp else {}
        if data.get("frozen"):
            print(f"  [FROZEN]   {c['amount']:>10s} {c['asset']:4s} @ {c['address']}")
        else:
            reason = data.get("reason", "unknown")
            print(f"  [MOVABLE]  {c['amount']:>10s} {c['asset']:4s} @ {c['address']}  ({reason})")

    print()
    print("[*] This mirrors the public outcome: a large fraction of stablecoins")
    print("    were frozen by issuers, while non-stable assets remained outside")
    print("    issuer control.")


if __name__ == "__main__":
    main()
