#!/usr/bin/env python3
"""
Phase 3 – Attempt the same class of forged requests against the hardened guard.
Demonstrates dual-control and velocity blocks.
"""
import json
import time
import urllib.request
import urllib.error

TARGET = "http://127.0.0.1:8091/internal/withdraw"
HEADERS_BASE = {"X-Service-Identity": "withdrawal-service"}


def post(body: dict, extra_headers: dict | None = None) -> tuple[int, str]:
    headers = {**HEADERS_BASE, **(extra_headers or {})}
    data = json.dumps(body).encode()
    req = urllib.request.Request(
        TARGET,
        data=data,
        headers={"Content-Type": "application/json", **headers},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def main():
    print("[*] Attacking hardened path (layered-withdrawal-guard on :8091)")
    print()

    # 1. Large amount without second approval → should be 403
    body = {"amount": "6.36", "asset": "BTC", "to": "bc1qattacker", "user_id": "alice"}
    print("[1] Large withdrawal, no second approval...")
    status, resp = post(body)
    print(f"    HTTP {status}: {resp}")
    print()

    # 2. Same request with correct second approval → should queue
    print("[2] Same request WITH second approval header...")
    status, resp = post(body, {"X-Second-Approval": "compliance-service"})
    print(f"    HTTP {status}: {resp}")
    print()

    # 3. Velocity test – fire several quickly
    print("[3] Velocity test – rapid successive requests...")
    for i in range(5):
        b = {"amount": "0.5", "asset": "ETH", "to": f"0xdemo{i}", "user_id": "bob"}
        status, resp = post(b, {"X-Second-Approval": "compliance-service"})
        print(f"    [{i+1}] HTTP {status}: {resp[:80]}...")
        time.sleep(0.15)

    print()
    print("[*] Hardened path correctly applied dual control and velocity limits.")
    print("    Compare with the vulnerable path in 02_forge_withdrawal_burst.py")


if __name__ == "__main__":
    main()
