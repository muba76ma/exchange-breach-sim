# exchange-breach-sim (Improved)

A safe, purple-team simulation lab that models the **internal trust-chain failure**
behind the October 2026 Binance-style withdrawal breach (~$6.3 B, multi-chain,
~20-minute core window).

> ⚠️ **Read [ETHICS.md](ETHICS.md) before running anything.**

## Attack-chain model (vulnerable path)

```
DevOps laptop
    │ (session / service material stolen)
    ▼
Service container foothold
    │ (forged internal request with trusted identity)
    ▼
withdrawal-service  ──mTLS / header trust──►  HSM mock (auto-signs)
    │
    ▼
On-chain sweep concept (EIP-7702 educational demo)
```

The lab deliberately shows why **implicit trust + missing dual control + weak
velocity limits** turn a laptop compromise into a multi-billion-dollar event.

## Real incident mapping (public facts only)

| Public fact (Oct 2026)                          | How this lab models it                          |
|------------------------------------------------|-------------------------------------------------|
| Compromised DevOps engineer laptop             | `attacker/01_simulate_laptop_compromise.sh`     |
| Access to service container                    | Multi-step attacker path                        |
| Unauthorized withdrawal transactions           | `attacker/02_forge_withdrawal_burst.py`         |
| No private-key leak from hot wallets           | HSM never exports keys; only signs              |
| Multi-chain, multi-asset, ~20 min core window  | Burst mode across BTC/ETH/USDT/USDC mocks       |
| Stablecoin freezes (~half of total)            | Optional issuer-freeze service                  |
| Complex (not one-click) attack process         | Multi-step attacker scripts                     |

## Lab components

| Component                    | Port (localhost) | Purpose                                      |
|-----------------------------|------------------|----------------------------------------------|
| withdrawal-service (vuln)   | 8081             | Implicit-trust path                          |
| hsm-mock                    | 8082             | Auto-signing HSM simulation                  |
| layered-withdrawal-guard    | 8091             | Hardened path (dual control + velocity)      |
| issuer-freeze               | 8092             | Mock stablecoin issuer freeze                |
| ledger-db                   | 5432             | Simple balance ledger                        |
| frontend                    | 8080             | Read-only status view                        |

## Quick start

```bash
# 1. Clone / enter the lab
cd exchange-breach-sim-improved

# 2. Start the environment
cp .env.example .env
docker compose up -d --build

# 3. Run the vulnerable attack path (multi-step)
bash attacker/01_simulate_laptop_compromise.sh
python3 attacker/02_forge_withdrawal_burst.py

# 4. Observe the vulnerable path succeed
docker compose logs hsm-mock | tail

# 5. Switch to the hardened path and see blocks
python3 attacker/03_attack_hardened.py

# 6. Optional: trigger issuer freeze simulation
python3 attacker/04_trigger_freeze.py
```

See [LAB-NOTES.md](LAB-NOTES.md) for the full walkthrough, timeline comparison,
and detection coverage.

## Defense highlights (hardened path)

- Velocity limit tuned to a short high-volume window
- Mandatory second approval for large amounts
- Short timelock before execution
- Structured JSON logging for SIEM ingestion
- Optional issuer-freeze coordination

## Detection rules

- Sigma: forged internal withdrawal (trusted identity without gateway auth)
- Sigma: high-velocity internal withdrawal burst
- Sigma: large withdrawal missing second approval
- YARA: EIP-7702 sweeper concept bytecode

## License

MIT — see [LICENSE](LICENSE).
