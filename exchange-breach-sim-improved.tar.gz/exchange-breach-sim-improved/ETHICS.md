# ⚠️ ETHICS & LEGAL NOTICE

This repository is a **defensive security research and purple-team training lab**.
It exists solely to help blue teams, security engineers, and researchers understand
and mitigate the class of internal trust-chain failures publicly reported in the
October 2026 Binance incident.

## Rules of Use

1. **Authorized use only** — Run this only on systems you own or have explicit
   written permission to test.
2. **Fake data only** — Every wallet address, token, balance, signature, and
   certificate in this lab is a harmless placeholder. No real private keys,
   no real funds, no real blockchain interaction.
3. **Isolated network** — All services bind to `127.0.0.1` or the Docker
   internal bridge network. Do not expose ports publicly.
4. **No weaponization** — Do not adapt any part of this lab for use against
   real infrastructure, exchanges, or third-party systems.
5. **Responsible disclosure** — If you discover a real vulnerability while
   studying these concepts, report it privately through proper channels.
6. **Educational intent** — This lab deliberately contains insecure patterns
   so that defenders can observe and practice blocking them. The presence of
   an insecure pattern is intentional and documented.

By cloning, building, or running any part of this repository you agree to
these terms.

**This is not a red-team toolkit. It is a teaching aid for defenders.**
