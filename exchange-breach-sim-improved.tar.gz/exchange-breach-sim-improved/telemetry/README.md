# Telemetry

All lab services support structured JSON logging when `LOG_FORMAT=json` is set
(the default in docker-compose).

```bash
# Follow logs
docker compose logs -f withdrawal-service hsm-mock layered-withdrawal-guard

# Or export to a file for later analysis
docker compose logs --no-color > telemetry/lab-run.log
```

To ship to a real OpenTelemetry collector, set:

```
OTEL_EXPORTER_OTLP_ENDPOINT=http://your-collector:4317
```

in `.env` (the services currently log to stdout; a full OTel SDK integration
can be added later if needed).

The Sigma rules under `defense/detection-rules/` are written against the
fields present in these structured logs.
