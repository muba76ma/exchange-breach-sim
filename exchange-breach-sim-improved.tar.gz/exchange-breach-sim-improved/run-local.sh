#!/usr/bin/env bash
# Convenience wrapper for local non-Docker quick checks (services must already be up).
set -euo pipefail
cd "$(dirname "$0")"

echo "== exchange-breach-sim (Improved) =="
echo
echo "1. Ensure docker compose is running:  make up"
echo "2. Vulnerable path:                  make attack"
echo "3. Hardened path:                    make attack-hardened"
echo "4. Issuer freeze demo:               make freeze"
echo "5. Status:                           make status"
echo
echo "Full details: README.md and LAB-NOTES.md"
echo "Ethics:       ETHICS.md"
